# 📊 Proyek Akhir: Student Dropout Analysis Dashboard & Machine Learning

------------------------------------------------------------------------

## 📌 Business Understanding

Institusi pendidikan menghadapi tantangan dalam mempertahankan mahasiswa
hingga lulus. Tingkat dropout yang tinggi dapat berdampak pada reputasi
institusi, kualitas pendidikan, serta efisiensi pengelolaan sumber daya.

Oleh karena itu, diperlukan analisis data untuk memahami faktor-faktor
yang mempengaruhi mahasiswa mengalami dropout serta membantu institusi
dalam mengambil keputusan berbasis data.

------------------------------------------------------------------------

## ❗ Permasalahan Bisnis

Permasalahan utama yang ingin diselesaikan dalam proyek ini adalah:

-   Tingginya jumlah mahasiswa yang mengalami dropout
-   Kurangnya pemahaman terhadap faktor yang mempengaruhi dropout
-   Belum adanya sistem prediksi untuk mengidentifikasi mahasiswa yang
    berpotensi dropout
-   Sulitnya institusi dalam memonitor performa mahasiswa secara cepat

------------------------------------------------------------------------

## 🎯 Cakupan Proyek

Cakupan proyek ini meliputi:

-   Data preprocessing (cleaning dan encoding)
-   Analisis eksploratif data (EDA)
-   Pembuatan dashboard visualisasi menggunakan Tableau
-   Pembangunan model machine learning untuk memprediksi risiko dropout
-   Evaluasi performa model
-   Penyusunan insight dan rekomendasi bagi institusi pendidikan

------------------------------------------------------------------------

## ⚙️ Persiapan

### 📂 Sumber Data

Dataset yang digunakan merupakan dataset performa mahasiswa yang berisi
berbagai informasi akademik dan finansial mahasiswa.

Contoh fitur dalam dataset: - Age at Enrollment - Admission Grade -
Scholarship Holder - Tuition Fees Up To Date - Status Mahasiswa (Dropout
/ Graduate / Enrolled)

Namun pada tahap pemodelan machine learning, data dengan status **Enrolled tidak digunakan**, 
sehingga model hanya memprediksi dua kategori yaitu **Dropout** dan **Graduate**.

📌 Link Dataset\
https://github.com/dicodingacademy/dicoding_dataset/blob/main/students_performance/data.csv

------------------------------------------------------------------------

### 🛠️ Setup Environment

1.  Membuat Virtual Environment

``` bash
python -m venv venv
```

2.  Mengaktifkan Virtual Environment

Windows

``` bash
venv\Scripts\activate
```

MacOS/Linux

``` bash
source venv/bin/activate
```

3.  Install Dependencies

``` bash
pip install -r requirements.txt
```

4.  Menjalankan Aplikasi Streamlit

``` bash
streamlit run app.py
```

------------------------------------------------------------------------

## 📊 Business Dashboard

Dashboard yang dibuat menampilkan berbagai insight terkait performa
mahasiswa dan risiko dropout.

Beberapa visualisasi yang ditampilkan antara lain:

-   Distribusi status mahasiswa (Dropout, Graduate, Enrolled)
-   Pengaruh status beasiswa terhadap dropout
-   Hubungan admission grade dengan status mahasiswa
-   Distribusi usia mahasiswa terhadap risiko dropout

📌 Link Dashboard Tableau\
https://public.tableau.com/app/profile/mahesa.masracesara/viz/StudentStatusAnalysis/Dashboard1?publish=yes

------------------------------------------------------------------------

## 🤖 Machine Learning Prototype

Prototype sistem prediksi dibuat menggunakan **Streamlit** untuk
memprediksi apakah mahasiswa berpotensi mengalami dropout.

User dapat memasukkan informasi:

-   Age at Enrollment
-   Admission Grade
-   Scholarship Holder
-   Tuition Fees Up To Date

📌 Link Prototype Streamlit\
https://bpdsmenyelesaikanpermasalahaninstitusipendidikan-bpds.streamlit.app/

------------------------------------------------------------------------

## 📌 Conclusion

Berdasarkan analisis data:

- Mahasiswa dengan **nilai admission lebih rendah** cenderung memiliki risiko dropout lebih tinggi.
- Mahasiswa tanpa **beasiswa** memiliki kecenderungan dropout lebih tinggi.
- **Status pembayaran tuition** berpengaruh terhadap keberlanjutan studi mahasiswa.
- **Usia saat masuk kuliah** juga berkaitan dengan kemungkinan dropout.

Pada tahap pemodelan, dua algoritma machine learning digunakan yaitu **Logistic Regression** dan **Random Forest**.

Hasil evaluasi menunjukkan bahwa model **Logistic Regression memiliki performa terbaik dengan akurasi sekitar 75%**, 
sedangkan Random Forest menghasilkan akurasi sekitar **70%**.

Oleh karena itu, Logistic Regression dipilih sebagai model yang digunakan dalam sistem prediksi dropout mahasiswa.

Model ini dapat dimanfaatkan sebagai **early warning system** bagi institusi pendidikan untuk mengidentifikasi 
mahasiswa yang berpotensi mengalami dropout sejak dini.

------------------------------------------------------------------------

## 🚀 Rekomendasi Action Items

Berdasarkan hasil analisis data dan model prediksi yang telah dikembangkan, beberapa rekomendasi yang dapat dilakukan oleh institusi pendidikan antara lain:

- Melakukan **monitoring performa akademik mahasiswa sejak semester pertama**, khususnya bagi mahasiswa dengan nilai akademik rendah.
- Menyediakan **dukungan finansial atau program beasiswa** bagi mahasiswa dengan keterbatasan ekonomi.
- Memantau mahasiswa dengan **status pembayaran tuition yang tertunda**.
- Mengembangkan **sistem early warning berbasis machine learning** untuk mendeteksi mahasiswa yang berpotensi mengalami dropout lebih awal.
- Mengembangkan **dashboard monitoring berbasis data** untuk membantu pihak akademik dalam memantau kondisi mahasiswa secara berkala.

------------------------------------------------------------------------

## 👤 Author

Mahesa Masracesara
